import os
import hashlib
from flask import (
    Blueprint, render_template, request,
    redirect, url_for, session, flash, abort, make_response
)
from database import get_db
from blueprints.auth import require_role

posts_bp = Blueprint("posts", __name__)


# ════════════════════════════════════════════════════════════════
#  HELPERS DE DEFENSA (todas implementadas con fallos intencionales)
# ════════════════════════════════════════════════════════════════

def _get_static_csrf_token():
    """
    DEFENSA ROTA #1 — Token CSRF estático en sesión.

    Genera el token UNA SOLA VEZ y lo guarda en:
      a) session['csrf_token']  — para validarlo en cada POST
      b) tabla user_tokens (DB) — "para auditoría de seguridad"

    El token NUNCA rota. Guardarlo en DB además lo hace disponible
    para cualquier proceso o endpoint que acceda a la base de datos,
    incluyendo la ruta /log que lo expone públicamente.

    Fallo explotable:
      El atacante lee el token desde /log (sin autenticar) y lo
      incrusta en exploit_static_token.html. Como nunca rota,
      el POST forjado siempre será aceptado por el servidor.
    """
    if "csrf_token" not in session:
        token = hashlib.sha256(os.urandom(32)).hexdigest()
        session["csrf_token"] = token

        # Persistir en DB para "auditoría" — VULNERABLE: /log lo expone
        if session.get("user_id"):
            db = get_db()
            db.execute(
                """INSERT INTO user_tokens (user_id, csrf_token, updated_at)
                   VALUES (?, ?, datetime('now'))
                   ON CONFLICT(user_id) DO UPDATE
                   SET csrf_token=excluded.csrf_token,
                       updated_at=excluded.updated_at""",
                (session["user_id"], token),
            )
            db.commit()

    return session["csrf_token"]


def _check_static_csrf_token():
    """
    Valida que el token del formulario coincida con el de sesión.
    La comparación es correcta, pero como el token no rota,
    un atacante que lo haya obtenido previamente siempre pasará.
    """
    form_token    = request.form.get("csrf_token", "")
    session_token = session.get("csrf_token", "")
    if not form_token or form_token != session_token:
        abort(403)


def _check_referer():
    """
    DEFENSA ROTA #3 — Validación de cabecera Referer por substring.

    Comprueba que 'localhost:5000' aparezca en cualquier parte
    de la URL del Referer.

    Fallo explotable (bypass):
      El atacante sirve su exploit desde un dominio como:
        http://localhost:5000.attacker.com/exploit.html
      La cadena 'localhost:5000' está presente como substring
      → la validación pasa → CSRF exitoso.

      Segundo bypass: si el navegador no envía Referer
      (petición desde HTTPS→HTTP, o Meta Referrer-Policy: no-referrer)
      la cabecera llega vacía y el check también falla silenciosamente
      porque se acepta Referer vacío para no romper flujos legítimos.
    """
    referer = request.headers.get("Referer", "")

    # VULNERABLE: ausencia de Referer se acepta sin error
    if not referer:
        return  # debería rechazarse, pero "no queremos romper nada"

    # VULNERABLE: substring match en lugar de parsear la URL correctamente
    allowed_host = "localhost:5000"
    if allowed_host not in referer:
        abort(403)
    # Una implementación segura usaría urllib.parse.urlparse(referer).netloc == allowed_host


# ════════════════════════════════════════════════════════════════
#  RUTAS PÚBLICAS
# ════════════════════════════════════════════════════════════════

@posts_bp.route("/feed")
def public_feed():
    db = get_db()
    posts = db.execute(
        """SELECT p.*, u.username FROM posts p
           JOIN users u ON u.id = p.author_id
           WHERE p.published=1
           ORDER BY p.created_at DESC"""
    ).fetchall()
    return render_template("posts/feed.html", posts=posts)


@posts_bp.route("/post/<int:post_id>")
def view_post(post_id):
    db = get_db()
    post = db.execute(
        """SELECT p.*, u.username FROM posts p
           JOIN users u ON u.id = p.author_id
           WHERE p.id=?""", (post_id,)
    ).fetchone()
    if not post:
        abort(404)
    if not post["published"] and session.get("user_id") != post["author_id"]:
        abort(403)
    return render_template("posts/detail.html", post=post)


@posts_bp.route("/my-posts")
@require_role("writer")
def my_posts():
    db = get_db()
    posts = db.execute(
        "SELECT * FROM posts WHERE author_id=? ORDER BY created_at DESC",
        (session["user_id"],)
    ).fetchall()
    return render_template("posts/my_posts.html", posts=posts)


# ════════════════════════════════════════════════════════════════
#  VULNERABILIDAD 1 — Token CSRF estático en sesión
#  Endpoint: POST /post/create
# ════════════════════════════════════════════════════════════════
@posts_bp.route("/post/create", methods=["GET", "POST"])
@require_role("writer")
def create_post():
    """
    DEFENSA APLICADA: Token CSRF en sesión incluido en el formulario.
    FALLO: el token es estático (nunca rota), por lo que es reutilizable
           indefinidamente una vez obtenido por el atacante.

    Flujo de ataque:
      1. Atacante obtiene el token via XSS (cookie HttpOnly=False)
         o leyendo el HTML del formulario si tiene acceso de lectura.
      2. Incrusta el token robado en su formulario cross-origin.
      3. El servidor acepta el request como legítimo.
    """
    csrf_token = _get_static_csrf_token()

    if request.method == "POST":
        # La validación existe pero el token nunca cambia → bypass posible
        _check_static_csrf_token()

        title     = request.form.get("title", "").strip()
        body      = request.form.get("body", "").strip()
        published = 1 if request.form.get("published") else 0

        if not title or not body:
            flash("Título y contenido son obligatorios.", "error")
            return redirect(url_for("posts.create_post"))

        db = get_db()
        db.execute(
            "INSERT INTO posts (title, body, author_id, published) VALUES (?,?,?,?)",
            (title, body, session["user_id"], published),
        )
        db.commit()
        flash("Post creado.", "success")
        return redirect(url_for("posts.my_posts"))

    return render_template("posts/create.html", csrf_token=csrf_token)


# ════════════════════════════════════════════════════════════════
#  VULNERABILIDAD 2 — Cookie SameSite=None como "token de delete"
#  Endpoint: POST /post/delete/<id>
# ════════════════════════════════════════════════════════════════
@posts_bp.route("/post/delete/<int:post_id>", methods=["POST"])
@require_role("writer")
def delete_post(post_id):
    """
    DEFENSA APLICADA: Se establece una cookie 'delete_token' y se valida
                      en cada request de eliminación.
    FALLO: la cookie se emite con SameSite=None, lo que hace que el
           navegador la envíe en cualquier request cross-origin.
           La "protección" no agrega ninguna barrera real.

    Flujo de ataque:
      1. El escritor visita /my-posts → el servidor emite delete_token.
      2. El atacante sirve exploit_samesite_delete.html desde otro origen.
      3. El navegador adjunta automáticamente la cookie (SameSite=None).
      4. El servidor valida la cookie → la encuentra → acepta el delete.

    Nota: también falta verificar que el post pertenece al usuario en sesión.
    """
    # Leer el token de la cookie enviada por el navegador
    cookie_token = request.cookies.get("delete_token", "")
    if not cookie_token:
        flash("Token de eliminación ausente.", "error")
        return redirect(url_for("posts.my_posts"))

    # La validación comprueba que la cookie exista — correcto en principio,
    # pero SameSite=None hace que el navegador siempre la envíe cross-origin.
    db = get_db()
    # VULNERABLE: tampoco verifica propiedad del post (IDOR)
    db.execute("DELETE FROM posts WHERE id=?", (post_id,))
    db.commit()
    flash("Post eliminado.", "success")

    response = make_response(redirect(url_for("posts.my_posts")))
    # Renovar la cookie — con la misma configuración insegura
    _set_delete_cookie(response)
    return response


def _set_delete_cookie(response):
    """
    Emite la cookie 'delete_token' con SameSite=None explícito.
    SameSite=None requiere Secure en navegadores modernos, pero como
    Secure=False aquí, algunos navegadores (Firefox, Chrome < 80 mode)
    la envían igualmente en HTTP — comportamiento que este lab explota.
    """
    token = hashlib.sha256(os.urandom(16)).hexdigest()
    response.set_cookie(
        "delete_token",
        value=token,
        samesite="None",   # VULNERABLE: cross-origin delivery
        httponly=False,    # VULNERABLE: legible por JS
        secure=False,      # VULNERABLE: no requiere HTTPS
        max_age=3600,
    )


@posts_bp.after_request
def attach_delete_cookie(response):
    """
    Emite la cookie delete_token en cada respuesta GET de escritores
    autenticados, para que esté disponible cuando vayan a eliminar.
    """
    if (request.method == "GET"
            and session.get("role") == "writer"
            and "delete_token" not in request.cookies):
        _set_delete_cookie(response)
    return response


# ════════════════════════════════════════════════════════════════
#  VULNERABILIDAD 3 — Validación de Referer por substring
#  Endpoint: POST /post/create  (también usado en nuevo post)
#  Se aplica como segunda capa en /post/create — ver también arriba
# ════════════════════════════════════════════════════════════════
#
#  La ruta /post/create ya implementa la vuln 1 (token estático).
#  El Referer check se expone de forma independiente en /post/share,
#  un endpoint que "comparte" un post y que usa SOLO Referer como defensa.

@posts_bp.route("/post/share/<int:post_id>", methods=["POST"])
@require_role("writer")
def share_post(post_id):
    """
    DEFENSA APLICADA: Valida la cabecera Referer antes de procesar.
    FALLO: usa substring match → bypass con dominio como
           http://localhost:5000.attacker.com/exploit.html

    Segundo fallo: Referer ausente se acepta silenciosamente.

    Flujo de ataque (bypass con subdomain):
      1. Atacante registra localhost:5000.attacker.com
      2. Sirve exploit_referer_share.html desde ese dominio
      3. El browser envía Referer: http://localhost:5000.attacker.com/...
      4. El check encuentra 'localhost:5000' como substring → acepta
      5. El post queda "compartido" (publicado) sin consentimiento del autor

    Flujo de ataque (bypass sin Referer):
      1. Atacante usa <meta name="referrer" content="no-referrer">
         en su página exploit
      2. El browser omite la cabecera Referer en el POST
      3. El servidor lo acepta porque referer vacío no se rechaza
    """
    # VULNERABLE: check con fallo de substring + ausencia aceptada
    _check_referer()

    db = get_db()
    post = db.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        abort(404)

    # Publicar el post al "compartirlo"
    db.execute("UPDATE posts SET published=1 WHERE id=?", (post_id,))
    db.commit()
    flash("Post compartido y publicado.", "success")
    return redirect(url_for("posts.my_posts"))


# ════════════════════════════════════════════════════════════════
#  RESTO DE RUTAS (sin cambios de lógica)
# ════════════════════════════════════════════════════════════════

@posts_bp.route("/post/edit/<int:post_id>", methods=["GET", "POST"])
@require_role("writer")
def edit_post(post_id):
    db = get_db()
    post = db.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        abort(404)
    if request.method == "POST":
        title     = request.form.get("title", "").strip()
        body      = request.form.get("body", "").strip()
        published = 1 if request.form.get("published") else 0
        db.execute(
            "UPDATE posts SET title=?, body=?, published=?, updated_at=datetime('now') WHERE id=?",
            (title, body, published, post_id),
        )
        db.commit()
        flash("Post actualizado.", "success")
        return redirect(url_for("posts.my_posts"))
    return render_template("posts/edit.html", post=post)


@posts_bp.route("/post/toggle/<int:post_id>", methods=["POST"])
@require_role("writer")
def toggle_publish(post_id):
    db = get_db()
    post = db.execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not post:
        abort(404)
    new_state = 0 if post["published"] else 1
    db.execute("UPDATE posts SET published=? WHERE id=?", (new_state, post_id))
    db.commit()
    return redirect(url_for("posts.my_posts"))
