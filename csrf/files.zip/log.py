import datetime
from flask import Blueprint, render_template
from database import get_db

log_bp = Blueprint("log", __name__)


# ════════════════════════════════════════════════════════════════
#  RUTA DE LEAK — /log
#  Simula un endpoint de logs del servidor expuesto públicamente.
#
#  Escenario realista:
#    El desarrollador agregó logging de sesiones para depurar
#    problemas de autenticación en producción y olvidó proteger
#    o eliminar el endpoint antes de desplegar.
#
#  Qué expone:
#    - El csrf_token de la sesión del primer escritor registrado.
#      Como el token es ESTÁTICO (nunca rota), leerlo una sola
#      vez es suficiente para forjar cualquier POST /post/create
#      en nombre de ese usuario indefinidamente.
#
#  Vector de ataque completo (Vuln #1):
#    1. Atacante accede a http://localhost:5000/log (sin autenticación)
#    2. Lee el csrf_token del escritor objetivo
#    3. Lo incrusta en exploit_static_token.html
#    4. El escritor visita la página maliciosa
#    5. El POST se ejecuta con token válido → aceptado por el servidor
#
#  En una aplicación real este leak puede ocurrir via:
#    - Endpoints de debug no eliminados
#    - Archivos de log accesibles via path traversal
#    - Errores 500 que incluyen el stack trace con datos de sesión
#    - Cabeceras de respuesta que filtran información interna
# ════════════════════════════════════════════════════════════════

def _build_log_entries(db):
    """
    Construye entradas de log simuladas.
    Incluye el csrf_token real del primer escritor si existe en DB.
    Rellena con entradas ficticias para dar apariencia de log real.
    """
    # Obtener el primer escritor registrado y su token de sesión
    # En este lab el token vive en la cookie de sesión Flask (firmada),
    # pero el servidor también lo guarda en la tabla sessions si existiera.
    # Aquí lo simulamos como si el servidor lo hubiera logueado al generarlo.
    first_writer = db.execute(
        "SELECT id, username, created_at FROM users WHERE role='writer' ORDER BY id ASC LIMIT 1"
    ).fetchone()

    entries = []

    # Entradas de log ficticias (antes del leak)
    base_entries = [
        ("INFO",  "app",     "Flask application started on port 5000"),
        ("INFO",  "db",      "SQLite3 database connection established: blog.db"),
        ("INFO",  "auth",    "Admin user seeded: admin"),
        ("DEBUG", "session", "Session secret key loaded from config"),
        ("INFO",  "app",     "Blueprints registered: auth, admin, posts, log"),
    ]

    now = datetime.datetime.now()
    for i, (level, module, msg) in enumerate(base_entries):
        ts = (now - datetime.timedelta(minutes=30 - i * 4)).strftime("%Y-%m-%d %H:%M:%S")
        entries.append({"ts": ts, "level": level, "module": module, "msg": msg, "highlight": False})

    if first_writer:
        # Simular que el token fue logueado cuando el usuario inició sesión
        login_ts = (now - datetime.timedelta(minutes=8)).strftime("%Y-%m-%d %H:%M:%S")
        entries.append({
            "ts":        login_ts,
            "level":     "DEBUG",
            "module":    "auth",
            "msg":       f"User '{first_writer['username']}' (id={first_writer['id']}) logged in successfully",
            "highlight": False,
        })

        token_ts = (now - datetime.timedelta(minutes=8)).strftime("%Y-%m-%d %H:%M:%S")
        entries.append({
            "ts":        token_ts,
            "level":     "DEBUG",
            "module":    "csrf",
            # LEAK: el token se loguea completo como parte del debug de sesión
            "msg":       f"[session debug] user_id={first_writer['id']} username={first_writer['username']} csrf_token=__CSRF_TOKEN_PLACEHOLDER__",
            "highlight": True,   # lo marcamos visualmente en el template
            "user_id":   first_writer["id"],
            "username":  first_writer["username"],
        })

        entries.append({
            "ts":        token_ts,
            "level":     "DEBUG",
            "module":    "csrf",
            "msg":       f"Static token bound to session (no rotation policy)",
            "highlight": False,
        })

    # Entradas de log ficticias (después del leak)
    post_entries = [
        ("INFO",  "posts",  "GET /post/create — 200"),
        ("INFO",  "posts",  "POST /post/create — 302 redirect to /my-posts"),
        ("INFO",  "posts",  "GET /my-posts — 200"),
    ]
    for i, (level, module, msg) in enumerate(post_entries):
        ts = (now - datetime.timedelta(minutes=3 - i)).strftime("%Y-%m-%d %H:%M:%S")
        entries.append({"ts": ts, "level": level, "module": module, "msg": msg, "highlight": False})

    return entries, first_writer


@log_bp.route("/log")
def server_log():
    """
    Endpoint de logs del servidor — accesible sin autenticación.
    VULNERABLE: expone el csrf_token estático del primer escritor.
    """
    db = get_db()
    entries, first_writer = _build_log_entries(db)

    # Obtener el token real de la DB de sesiones si existe,
    # o generarlo de forma consistente para el demo
    csrf_token = None
    if first_writer:
        # En este lab el token se genera al primer GET /post/create.
        # Lo leemos desde la tabla interna si está disponible,
        # o mostramos un placeholder instructivo.
        row = db.execute(
            "SELECT csrf_token FROM user_tokens WHERE user_id=?",
            (first_writer["id"],)
        ).fetchone() if _table_exists(db, "user_tokens") else None

        csrf_token = row["csrf_token"] if row else None

    return render_template(
        "log/server_log.html",
        entries=entries,
        first_writer=first_writer,
        csrf_token=csrf_token,
    )


def _table_exists(db, table_name):
    row = db.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table_name,)
    ).fetchone()
    return row is not None
